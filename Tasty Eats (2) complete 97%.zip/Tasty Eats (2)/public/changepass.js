import {
    initializeApp,
    getApps,
} from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import {
    getAuth,
    EmailAuthProvider, // Add this import
    reauthenticateWithCredential,
    updatePassword,
} from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };

// DOM Elements
const changePasswordForm = document.getElementById("changePasswordForm");
const popup = document.getElementById("popup");
const popupOkButton = document.getElementById("popup-ok");

// Show popup function
function showPopup(message, success = true) {
    const popupMessage = popup.querySelector("h3");
    const popupDescription = popup.querySelector("p");
    popupMessage.textContent = success ? "Success" : "Error";
    popupDescription.textContent = message;
    popup.classList.add("open-popup");
}

// Hide popup when "OK" is clicked
popupOkButton.addEventListener("click", () => {
    popup.classList.remove("open-popup");
});

// Handle form submission
changePasswordForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const oldPassword = document.getElementById("oldPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    // Input validations
    if (newPassword !== confirmPassword) {
        showPopup("New password and confirmation do not match.", false);
        return;
    }

    if (newPassword.length < 6) {
        showPopup("Password must be at least 6 characters long.", false);
        return;
    }

    const user = auth.currentUser;

    if (!user) {
        showPopup("User is not authenticated. Please log in again.", false);
        return;
    }

    try {
        // Reauthenticate the user
        const credential = EmailAuthProvider.credential(user.email, oldPassword);
        await reauthenticateWithCredential(user, credential);

        // Update the password
        await updatePassword(user, newPassword);
        showPopup("Your password has been updated successfully.", true);
        changePasswordForm.reset(); // Reset the form
    } catch (error) {
        console.error("Error updating password:", error);
        const errorMessage =
            error.code === "auth/wrong-password"
                ? "The current password is incorrect."
                : "An error occurred while updating the password. Please try again.";
        showPopup(errorMessage, false);
    }
});