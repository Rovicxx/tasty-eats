document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('changePasswordForm');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const oldPassword = document.getElementById('oldPassword').value.trim();
        const newPassword = document.getElementById('newPassword').value.trim();
        const confirmPassword = document.getElementById('confirmPassword').value.trim();

        if (newPassword !== confirmPassword) {
            alert('New password and confirmation do not match!');
            return;
        }

        try {
            const response = await fakeApiCall(oldPassword, newPassword);

            if (response.success) {
                alert('Password changed successfully!');
                window.location.href = 'profile.html'; 
            } else {
                alert(`Error: ${response.message}`);
            }
        } catch (error) {
            console.error('An error occurred:', error);
            alert('An unexpected error occurred. Please try again later.');
        }
    });

// Attach close event to popup OK button
popupOkButton.addEventListener("click", closePopup);

    async function fakeApiCall(oldPassword, newPassword) {
        return new Promise((resolve) => {
            setTimeout(() => {
                if (oldPassword && newPassword) {
                    resolve({ success: true });
                } else {
                    resolve({ success: false, message: 'Invalid input' });
                }
            }, 1000); 
        });
    }
});
