document.addEventListener('DOMContentLoaded', () => {
        const form = document.getElementById('updateProfileForm');
        const avatarUpload = document.getElementById('avatar-upload');
        const displayPhoto = document.getElementById('display-photo');
        
        const user = auth.currentUser;
    
        // Load existing profile data from Firebase
        if (user) {
            const userRef = doc(db, "users", user.uid);
            getDoc(userRef).then((docSnap) => {
                if (docSnap.exists()) {
                    const userData = docSnap.data();
                    document.getElementById('name').value = userData.username || '';
                    document.getElementById('email').value = userData.email || '';
                    document.getElementById('bio').value = userData.bio || '';
                    if (userData.profilePhoto) {
                        displayPhoto.src = userData.profilePhoto;
                    }
                }
            });
        }

    form.addEventListener('submit', async (event) => {
        event.preventDefault(); // Prevent the default form submission

        const username = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const bio = document.getElementById('bio').value.trim();

        // Basic validation
        if (!username || !email || !validateEmail(email)) {
            alert('Please enter a valid username and email.');
            return;
        }

        try {
            const userRef = doc(db, "users", user.uid);

            // Check if a new profile photo was uploaded
            let profilePhotoUrl = null;
            const file = avatarUpload.files[0];
            if (file) {
                const storageRef = ref(storage, `profile_pictures/${user.uid}`);
                const uploadTask = uploadBytesResumable(storageRef, file);

                // Wait for the file upload to finish
                await uploadTask.then(() => {
                    return getDownloadURL(uploadTask.snapshot.ref);
                }).then((downloadURL) => {
                    profilePhotoUrl = downloadURL;
                }).catch((error) => {
                    console.error('Error uploading image:', error);
                    alert('Failed to upload image. Please try again.');
                });
            }

            // Update user data in Firestore
            await updateDoc(userRef, {
                username,
                email,
                bio,
                profilePhoto: profilePhotoUrl || null, // If no photo, use null
            });

            alert('Profile updated successfully!');
            window.location.href = 'profile.html'; // Redirect to the profile page
        } catch (error) {
            console.error('An error occurred:', error);
            alert('An unexpected error occurred. Please try again later.');
        }
    });

    // Email validation function
    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});

