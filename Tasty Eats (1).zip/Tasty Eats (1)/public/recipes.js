// Import necessary Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import {
  getFirestore,
  doc,
  getDoc,
  collection,
  addDoc,
  query,
  getDocs,
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";
import {
  getAuth,
  onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Variable to store the current user's information
let currentUser = null;

// Check authentication status
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
  } else {
    currentUser = null;
    alert("You must be logged in to submit a review.");
  }
});

// Fetch recipe details
async function loadRecipeDetails() {
  const urlParams = new URLSearchParams(window.location.search);
  const recipeId = urlParams.get("id");
  if (!recipeId) {
    console.error("Recipe ID missing in URL!");
    return;
  }

  try {
    const recipeDocRef = doc(db, "recipes", recipeId);
    const recipeDoc = await getDoc(recipeDocRef);
    if (recipeDoc.exists()) {
      const recipeData = recipeDoc.data();

      document.getElementById("recipe-title").textContent =
        recipeData.title || "Untitled Recipe";
      document.getElementById("recipe-image").src =
        recipeData.imageUrl || "images/placeholder-recipe.jpg";

      const ingredientsList = document.getElementById("ingredients-list");
      ingredientsList.innerHTML = "";
      (recipeData.ingredients || []).forEach((ingredient) => {
        const listItem = document.createElement("li");
        listItem.textContent = ingredient;
        ingredientsList.appendChild(listItem);
      });

      document.getElementById("instructions").textContent =
        recipeData.instructions || "No instructions provided.";

      // Fetch reviews from the subcollection
      await loadReviews(recipeId);
    } else {
      console.error("Recipe not found!");
      document.querySelector(".recipe-container").textContent =
        "Recipe not found.";
    }
  } catch (error) {
    console.error("Error fetching recipe details:", error);
    document.querySelector(".recipe-container").textContent =
      "Error loading recipe.";
  }
}

// Load reviews from the Firestore subcollection
async function loadReviews(recipeId) {
  try {
    const reviewsCollectionRef = collection(db, "recipes", recipeId, "reviews");
    const reviewsQuery = query(reviewsCollectionRef);
    const querySnapshot = await getDocs(reviewsQuery);

    const reviewList = document.getElementById("reviewList");
    reviewList.innerHTML = "";
    querySnapshot.forEach((doc) => {
      const review = doc.data();
      const reviewItem = createReviewElement(review);
      reviewList.appendChild(reviewItem);
    });
  } catch (error) {
    console.error("Error fetching reviews:", error);
  }
}

// Create a review element
function createReviewElement(review) {
  const listItem = document.createElement("li");
  listItem.classList.add("review");
  listItem.innerHTML = `
    <div class="review-author">
      <img class="review-author-img" src="images/100-1005846_waiter-free-icon-avatar-profile-circle-png.png" alt="Author">
      <span class="author-name">${review.author || "Anonymous"}</span>
    </div>
    <div class="review-content">
      <p class="review-title">${review.title || "Untitled"}</p>
      <p>${review.text}</p>
      <div class="rating-stars">${"★".repeat(review.rating)}${"☆".repeat(
    5 - review.rating
  )}</div>
    </div>
  `;
  return listItem;
}

// Add review functionality
async function addReview() {
  const recipeId = new URLSearchParams(window.location.search).get("id");
  if (!recipeId) return;

  if (!currentUser) {
    alert("You must be logged in to add a review.");
    return;
  }

  const reviewText = document.getElementById("reviewText").value.trim();
  const rating = document.querySelector('input[name="rate"]:checked')?.value;

  if (!reviewText || !rating) {
    alert("Please complete the review and select a rating.");
    return;
  }

  const newReview = {
    author: currentUser.displayName || "Anonymous",
    title: "Review:", // Optionally allow users to add a title
    text: reviewText,
    rating: parseInt(rating),
    timestamp: new Date().toISOString(),
  };

  try {
    const reviewsCollectionRef = collection(db, "recipes", recipeId, "reviews");
    await addDoc(reviewsCollectionRef, newReview);

    // Add review to the page without reload
    const reviewList = document.getElementById("reviewList");
    const reviewItem = createReviewElement(newReview);
    reviewList.appendChild(reviewItem);

    document.getElementById("reviewText").value = "";
    document.querySelector('input[name="rate"]:checked').checked = false;
    document.getElementById("reviewModal").style.display = "none";
  } catch (error) {
    console.error("Error adding review:", error);
    alert("Failed to submit the review. Please try again.");
  }
}

// Modal functionality
document.getElementById("addReviewBtn").onclick = () => {
  if (!currentUser) {
    alert("You must be logged in to add a review.");
    return;
  }
  document.getElementById("reviewModal").style.display = "block";
};

document.getElementById("closeModalBtn").onclick = () => {
  document.getElementById("reviewModal").style.display = "none";
};

window.onclick = (event) => {
  if (event.target === document.getElementById("reviewModal")) {
    document.getElementById("reviewModal").style.display = "none";
  }
};

document.getElementById("submitReviewBtn").onclick = addReview;

// Load the recipe details on page load
document.addEventListener("DOMContentLoaded", loadRecipeDetails);