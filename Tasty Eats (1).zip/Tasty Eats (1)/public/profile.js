// Initialize Firebase (ensure this is included)
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import { getFirestore, doc, getDoc, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase app and services
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// DOM Elements
const usernameElement = document.querySelector('.profile-info h2');
const bioElement = document.querySelector('.Description');
const recipeGrid = document.getElementById('recipeGrid'); // For displaying user recipes

// Static Bio for all users
const staticBio = "I am a dedicated chef passionate about creating delicious and innovative dishes, blending flavors and techniques to craft memorable culinary experiences.";
bioElement.textContent = staticBio;

onAuthStateChanged(auth, async (user) => {
    if (user) {
        const userDocRef = doc(db, "users", user.uid); 
        try {
            
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
                const username = userDoc.data().username; 
                usernameElement.textContent = username || "Default Username";
                
                fetchUserRecipes(user.uid);
            } else {
                console.error("User document not found!");
            }
        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    } else {
        window.location.href = "login.html";
    }
});

async function fetchUserRecipes(userId) {
    const recipesRef = collection(db, "recipes");
    const q = query(recipesRef, where("userId", "==", userId));

    try {
        const querySnapshot = await getDocs(q);
        recipeGrid.innerHTML = ""; 
        if (querySnapshot.empty) {
            recipeGrid.innerHTML = "<p>No recipes found.</p>";
            return;
        }
        querySnapshot.forEach((doc) => {
            const recipe = doc.data();
            const recipeCard = createRecipeCard(recipe);
            recipeGrid.appendChild(recipeCard);
        });
    } catch (error) {
        console.error("Error fetching user recipes:", error);
    }
}

function createRecipeCard(recipe) {
    const card = document.createElement("div");
    card.className = "recipe-card";

    card.innerHTML = `
        <img src="${recipe.imageUrl}" alt="${recipe.title}">
        <p>${recipe.title}</p>
        <p>⭐⭐⭐⭐⭐ (${recipe.ratingCount})</p>
        <button class="delete-btn">
            <img src="images/delete_icon.png" alt="Delete">
        </button>`;

    const deleteButton = card.querySelector(".delete-btn");
    deleteButton.addEventListener("click", function (event) {
        event.stopPropagation(); 
        card.remove(); 
        deleteRecipe(recipe.id); 
    });

    card.addEventListener("click", function () {
        localStorage.setItem("selectedRecipe", JSON.stringify(recipe));
        window.location.href = "recipes.html"; 
    });
    return card;
}

function displayRecipe(recipeData) {
    const recipeCard = document.createElement("div");
    recipeCard.classList.add("recipe-card");
    
    recipeCard.innerHTML = `
    <img src="${recipeData.imageUrl || "images/placeholder-recipe.jpg"}" alt="${recipeData.title}">
    <p>${recipeData.title}</p>`;
    
    recipeCard.addEventListener("click", () => {
    window.location.href = `recipes.html?id=${recipeData.id}`;
    });
    
    allRecipesSection.appendChild(recipeCard);

}

document.addEventListener('DOMContentLoaded', () => {
    const usernameElement = document.getElementById('profile-username');
    const emailElement = document.getElementById('profile-email');
    const bioElement = document.getElementById('profile-bio');
    const displayPhoto = document.getElementById('display-photo');
    
    const user = auth.currentUser;

    if (user) {
        const userRef = doc(db, "users", user.uid);

        getDoc(userRef).then((docSnap) => {
            if (docSnap.exists()) {
                const userData = docSnap.data();
                usernameElement.textContent = userData.username || 'No Username';
                emailElement.textContent = userData.email || 'No Email';
                bioElement.textContent = userData.bio || 'No Bio';
                
                if (userData.profilePhoto) {
                    displayPhoto.src = userData.profilePhoto;
                } else {
                    displayPhoto.src = 'default-profile-photo.jpg'; 
                }
            }
        }).catch((error) => {
            console.error('Error getting document:', error);
        });
    } else {
        alert('No user logged in');
        window.location.href = 'index.html'; 
    }
});

const logoutButton = document.getElementById("logoutButton");

logoutButton.addEventListener("click", function (event) {
    event.preventDefault(); 

    signOut();

    window.location.href = "index.html";
});

function signOut() {
    const auth = getAuth(); 
    signOut(auth).then(() => {
        console.log("User logged out successfully");
    }).catch((error) => {
        console.error("Logout error:", error);
    });
}

