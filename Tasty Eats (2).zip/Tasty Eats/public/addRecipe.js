// Import necessary Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";

// Firebase configuration (make sure this matches your setup)
const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Check if user is logged in before allowing them to add a recipe
let currentUser = null;
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
  } else {
    alert("You must be logged in to add a recipe.");
    window.location.href = "index.html"; // Redirect to login page if not logged in
  }
});

// Cloudinary upload widget setup
document.getElementById('uploadWidget').addEventListener('click', function () {
  cloudinary.openUploadWidget(
    {
      cloudName: 'dgdzmrhc4', // Replace with your Cloudinary cloud name
      uploadPreset: 'recipe-images-upload', // Replace with your upload preset name
      folder: 'recipe_images', // Optional: specify folder
      sources: ['local', 'url'], // Allow local file uploads and URLs
    },
    (error, result) => {
      if (!error && result && result.event === 'success') {
        console.log('Uploaded image:', result.info.secure_url);
        // Save the uploaded image URL to the hidden input field
        document.getElementById('imageURL').value = result.info.secure_url;
        alert("Image uploaded successfully!");
      } else if (error) {
        alert("Error uploading image. Please try again.");
        console.error("Error uploading image: ", error);
      }
    }
  );
});

// Handle form submission
const recipeForm = document.getElementById("recipeForm");
recipeForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  // Get form values
  const recipeTitle = document.getElementById('recipeTitle').value.trim();
  const instructions = document.getElementById('instructions').value.trim();
  const ingredients = document.getElementById('ingredients').value.trim().split(",");
  const imageUrl = document.getElementById('imageURL').value; // Get the image URL from the hidden input

  if (!recipeTitle || !instructions || !ingredients.length || !imageUrl) {
    alert("Please fill out all fields, including the image!");
    return;
  }

  // Add recipe to Firestore
  try {
    if (!currentUser) {
      alert("You must be logged in to add a recipe.");
      return;
    }

    await addDoc(collection(db, "recipes"), {
      title: recipeTitle,
      instructions,
      ingredients,
      imageUrl,
      userId: currentUser.uid,
      timestamp: new Date(),
    });

    alert("Recipe added successfully!");
    recipeForm.reset();
  } catch (error) {
    console.error("Error adding recipe:", error);
    alert("Failed to add recipe. Please try again.");
  }
});