// Import necessary Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, query, onSnapshot } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Real-time listener to fetch unique ingredients from Firestore
function fetchIngredientsRealTime() {
  const recipesCollection = collection(db, "recipes");
  const q = query(recipesCollection);

  onSnapshot(q, (snapshot) => {
    const uniqueIngredients = new Set();
    snapshot.forEach((doc) => {
      const recipe = doc.data();
      if (recipe.ingredients && Array.isArray(recipe.ingredients)) {
        recipe.ingredients.forEach((ingredient) => uniqueIngredients.add(ingredient.trim()));
      }
    });

    populateChecklist(Array.from(uniqueIngredients));
  });
}

// Populate the checklist with ingredients
function populateChecklist(ingredients) {
  const ingredientList = document.getElementById("ingredient-list");
  ingredientList.innerHTML = ""; // Clear existing ingredients

  ingredients.forEach((ingredient) => {
    const listItem = document.createElement("li");
    listItem.innerHTML = `<input type="checkbox" id="${ingredient}"> ${ingredient}`;
    ingredientList.appendChild(listItem);
  });

  // Attach filterRecipes function to checkboxes
  const checkboxes = ingredientList.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach((checkbox) => {
    checkbox.addEventListener("change", filterRecipes);
  });
}

// Real-time listener to fetch recipes from Firestore
function fetchRecipesRealTime() {
  const recipesCollection = collection(db, "recipes");
  const q = query(recipesCollection);

  onSnapshot(q, (snapshot) => {
    const recipes = [];
    snapshot.forEach((doc) => {
      recipes.push({ id: doc.id, ...doc.data() });
    });

    populateRecipes(recipes);
  });
}

// Populate the recipe grid with recipes
function populateRecipes(recipes) {
  const recipeGrid = document.querySelector(".recipe-grid");
  recipeGrid.innerHTML = ""; // Clear existing recipes

  recipes.forEach((recipe) => {
    const recipeCard = document.createElement("div");
    recipeCard.classList.add("recipe-card");
    recipeCard.setAttribute("data-ingredients", recipe.ingredients.join(","));

    recipeCard.innerHTML = `
      <a href="recipes.html?id=${recipe.id}">
        <img src="${recipe.imageUrl || "assets/placeholder.jpg"}" alt="${recipe.title}">
      </a>
      <p>${recipe.title}</p>
      <p>⭐⭐⭐⭐⭐ (${recipe.rating || "0"})</p>
    `;

    recipeGrid.appendChild(recipeCard);
  });
}

// Filter recipes based on selected ingredients
function filterRecipes() {
  const selectedIngredients = [];
  const checkboxes = document.querySelectorAll('.ingredients input[type="checkbox"]:checked');

  // Get all selected ingredients
  checkboxes.forEach((checkbox) => {
    selectedIngredients.push(checkbox.id);
  });

  // Get all recipe cards
  const recipeCards = document.querySelectorAll('.recipe-card');

  recipeCards.forEach((card) => {
    const recipeIngredients = card.getAttribute('data-ingredients').split(',');

    // Check if the recipe contains any of the selected ingredients
    const matches = selectedIngredients.some((ingredient) => recipeIngredients.includes(ingredient));

    // Show or hide the recipe based on matches
    card.style.display = matches || selectedIngredients.length === 0 ? "block" : "none";
  });
}

// Filter ingredients as you type in the search bar
function filterIngredients() {
  const searchQuery = document.getElementById('ingredient-search').value.toLowerCase();
  const ingredientItems = document.querySelectorAll('#ingredient-list li');

  ingredientItems.forEach((item) => {
    const ingredientName = item.textContent || item.innerText;
    item.style.display = ingredientName.toLowerCase().includes(searchQuery) ? "" : "none";
  });
}

// Attach the filterIngredients function to the search input
document.getElementById('ingredient-search').addEventListener('input', filterIngredients);

// Initialize the real-time ingredient checklist and recipe population
document.addEventListener("DOMContentLoaded", () => {
  fetchIngredientsRealTime();
  fetchRecipesRealTime();
});

