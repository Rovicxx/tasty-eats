document.addEventListener('DOMContentLoaded', () => {
    // Fetch current user details and populate the form
    fetch('/getCurrentUserDetails')
        .then(response => response.json())
        .then(data => {
            // Populate form fields with fetched data
            document.getElementById('email').value = data.email;
            document.getElementById('username').value = data.username;
        })
        .catch(error => console.error('Error fetching user details:', error));

    // Handle form submission
    document.querySelector('form').addEventListener('submit', (event) => {
        event.preventDefault(); // Prevent default form submission

        // Collect form data
        const email = document.getElementById('email').value;
        const username = document.getElementById('username').value;
        const bio = document.getElementById('bio').value;

        const data = {
            newEmail: email,
            newUsername: username,
            newBio: bio 
        };

        // Send updated user details to the server
        fetch('/updateUserDetails', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Profile updated successfully');
                window.location.href = 'profile.html'; // Redirect to the profile page
            } else {
                alert(data.error); // Display error message from the server
            }
        })
        .catch(error => console.error('Error updating user details:', error));
    });

    // Handle photo upload and preview
   const image_input = document.querySelector("#avatar-upload");
   var uploaded_image = "";

   image_input.addEventListener("change", function(){
    const reader = new FileReader();
    reader.addEventListener("load", () => {
        uploaded_image = reader.result;
        document.querySelector("#display-photo").computedStyleMap.backgroundImage = 'url(${uploaded_image})';
    });
    reader.readAsDataURL(this.file[0]);
   })
})