import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, query, getDocs } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Function to load recipes and display them in the grid
async function loadAllRecipes() {
  const allRecipesGrid = document.querySelector(".all-recipes-grid"); // Target grid for "All Recipes"

  // Query Firestore for all recipes in the "recipes" collection
  const q = query(collection(db, "recipes"));

  try {
    const querySnapshot = await getDocs(q);

    querySnapshot.forEach((doc) => {
      const recipe = doc.data();
      const recipeId = doc.id;

      // Dynamically create recipe cards
      const recipeCard = document.createElement("div");
      recipeCard.classList.add("recipe-card");

      recipeCard.innerHTML = `
        <img src="${recipe.imageUrl || "images/placeholder-recipe.jpg"}" alt="${recipe.title}">
        <p>${recipe.title}</p>
      `;

      // Add click event listener for redirecting to recipes.html
      recipeCard.addEventListener("click", () => {
        window.location.href = `recipes.html?id=${recipeId}`;
      });

      // Append the card to the grid
      allRecipesGrid.appendChild(recipeCard);
    });
  } catch (error) {
    console.error("Error loading recipes:", error);
  }
}

// Call loadAllRecipes when the DOM is fully loaded
document.addEventListener("DOMContentLoaded", loadAllRecipes);