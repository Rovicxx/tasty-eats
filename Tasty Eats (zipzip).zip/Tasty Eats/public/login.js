import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import {
    getAuth,
    signInWithEmailAndPassword,
    GoogleAuthProvider,
    signInWithPopup
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";

// Firebase configuration (same as the one you used for signup)
const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Login with email and password
document.querySelector("form").addEventListener("submit", async (event) => {
    event.preventDefault();

    const email = document.querySelector("input[type='email']").value.trim();
    const password = document.querySelector("input[type='password']").value.trim();

    try {
        // Sign in user
        await signInWithEmailAndPassword(auth, email, password);
        alert("Login successful! Redirecting...");
        window.location.href = "landing.html"; // Redirect to the profile page or dashboard
    } catch (error) {
        console.error("Error during login:", error);
        alert(`Login failed: ${error.message}`);
    }
});

// Google Sign-In
document.querySelector(".social-login.google").addEventListener("click", async () => {
    const provider = new GoogleAuthProvider();

    try {
        // Sign in with Google
        await signInWithPopup(auth, provider);
        alert("Signed in successfully with Google! Redirecting...");
        window.location.href = "landing.html"; // Redirect to the profile page or dashboard
    } catch (error) {
        console.error("Error with Google sign-in:", error);
        alert(`Failed to sign in with Google: ${error.message}`);
    }
});