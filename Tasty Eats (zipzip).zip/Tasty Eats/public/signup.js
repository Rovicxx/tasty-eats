import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import {
    getAuth,
    GoogleAuthProvider,
    signInWithPopup,
    createUserWithEmailAndPassword,
    updateProfile
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import {
    getFirestore,
    doc,
    setDoc,
    getDoc
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Email/Password Signup with better UX
document.getElementById("signupButton").addEventListener("click", async (event) => {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    // Show loading indicator
    const signupButton = document.getElementById("signupButton");
    signupButton.textContent = "Signing up...";
    signupButton.disabled = true;

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;

        // Update profile with username
        await updateProfile(user, {
            displayName: username
        });

        // Save user to Firestore
        await setDoc(doc(db, "users", user.uid), {
            uid: user.uid,
            email: email,
            username: username,
            createdAt: new Date()
        });

        alert("Signup successful!");
        window.location.href = "index.html"; // Redirect to index.html
    } catch (error) {
        console.error("Error during signup:", error);
        alert(`Signup failed: ${error.message}`);
    } finally {
        // Reset button state
        signupButton.textContent = "Sign Up";
        signupButton.disabled = false;
    }
});

// Google Sign-In with better UX
document.getElementById("googleSignIn").addEventListener("click", async () => {
    const provider = new GoogleAuthProvider();

    // Show loading indicator
    const googleSignInButton = document.getElementById("googleSignIn");
    googleSignInButton.textContent = "Loading...";
    googleSignInButton.disabled = true;

    try {
        const result = await signInWithPopup(auth, provider);
        const user = result.user;

        // Check if user exists in Firestore
        const userDocRef = doc(db, "users", user.uid);
        const userDoc = await getDoc(userDocRef);

        if (!userDoc.exists()) {
            // Add new user to Firestore
            await setDoc(userDocRef, {
                uid: user.uid,
                email: user.email,
                username: user.displayName || "Google User",
                createdAt: new Date()
            });
        }

        alert("Signed in successfully with Google!");
        window.location.href = "index.html"; // Redirect to index.html
    } catch (error) {
        if (error.code !== "auth/popup-closed-by-user") {
            console.error("Error with Google sign-in:", error);
            alert(`Failed to sign in with Google: ${error.message}`);
        }
    } finally {
        // Reset button state
        googleSignInButton.textContent = "Continue with Google";
        googleSignInButton.disabled = false;
    }
});