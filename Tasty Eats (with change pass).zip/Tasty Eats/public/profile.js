// Initialize Firebase (ensure this is included)
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import { getFirestore, doc, getDoc, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1",
};
document.addEventListener('DOMContentLoaded', () => {

    const profilePhoto = localStorage.getItem('profilePhoto') || 'images/dp_background.jpg';
    const username = localStorage.getItem('username') || 'Default Username';
    const bio = localStorage.getItem('bio') || 'This is the default bio.';
    const recipesCount = localStorage.getItem('recipesCount') || '0';

    const profileImageElement = document.querySelector('.profile-image img');
    if (profileImageElement) {
        profileImageElement.src = profilePhoto;
    }

    const usernameElement = document.querySelector('.profile-info h2');
    if (usernameElement) {
        usernameElement.textContent = username;
    }

    const bioElement = document.querySelector('.Description');
    if (bioElement) {
        bioElement.textContent = bio;
    }

    const recipesCountElement = document.querySelector('.Recipes-count');
    if (recipesCountElement) {
        recipesCountElement.textContent = `Recipes posted: ${recipesCount}`;
    }

    const recipeGrid = document.getElementById('recipeGrid');
    if (recipeGrid) {
        recipeGrid.innerHTML = '<p>No recipes to display. Start by adding your first recipe!</p>';
    }
});
