import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import {
    getAuth,
    GoogleAuthProvider,
    signInWithPopup,
    createUserWithEmailAndPassword,
    updateProfile
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import {
    getFirestore,
    doc,
    setDoc,
    getDoc
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const popup = document.getElementById("popup");

// Functions for managing the popup
window.openPopup = function () {
    popup.classList.add("open-popup");
};

window.closePopup = function () {
    popup.classList.remove("open-popup");
};

// Email/Password Signup with better UX
document.getElementById("signupButton").addEventListener("click", async (event) => {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    // Show loading indicator
    const signupButton = document.getElementById("signupButton");
    signupButton.textContent = "Signing up...";
    signupButton.disabled = true;

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;

        // Update profile with username
        await updateProfile(user, {
            displayName: username
        });

        // Save user to Firestore
        await setDoc(doc(db, "users", user.uid), {
            uid: user.uid,
            email: email,
            username: username,
            createdAt: new Date()
        });

        // Open popup on success
        openPopup();
    } catch (error) {
        console.error("Error during signup:", error);
        alert(`Signup failed: ${error.message}`);
    } finally {
        // Reset button state
        signupButton.textContent = "Sign Up";
        signupButton.disabled = false;
    }
});

// Attach event listener to the "OK" button
const okButton = document.getElementById("closePopupButton");
if (okButton) {
    okButton.addEventListener("click", () => {
        closePopup();
        window.location.href = "index.html";
    });
} else {
    console.error("OK button in popup not found.");
}