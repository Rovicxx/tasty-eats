import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, query, getDocs } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Function to load recipes and display them in the grid
async function loadAllRecipes() {
  const allRecipesSection = document.querySelector('.all-recipes-section .all-recipes-grid');
  const searchInput = document.getElementById('search-bar');
  const searchIcon = document.querySelector('.search-icon');

  let allRecipes = [];

  // Fetch recipes from Firestore
  async function fetchRecipes() {
    allRecipesSection.innerHTML = ""; // Clear the grid before loading recipes
    const recipesRef = collection(db, "recipes");
    
    try {
      const querySnapshot = await getDocs(recipesRef);

      if (querySnapshot.empty) {
        allRecipesSection.innerHTML = "<p class='no-recipes-message'>No recipes found.</p>";
      } else {
        allRecipes = [];
        querySnapshot.forEach((doc) => {
          const recipeData = { ...doc.data(), id: doc.id }; // Add the recipe ID to the data
          allRecipes.push(recipeData);
          displayRecipe(recipeData);
        });
      }
    } catch (error) {
      console.error("Error loading recipes:", error);
    }
  }

  // Function to display a single recipe
  function displayRecipe(recipeData) {
    const recipeCard = document.createElement("div");
    recipeCard.classList.add("recipe-card");

    recipeCard.innerHTML = `
      <img src="${recipeData.imageUrl || "images/placeholder-recipe.jpg"}" alt="${recipeData.title}">
      <p>${recipeData.title}</p>
    `;

    // Add click event to redirect to recipe details
    recipeCard.addEventListener("click", () => {
      window.location.href = `recipes.html?id=${recipeData.id}`;
    });

    allRecipesSection.appendChild(recipeCard);
  }

  // Filter recipes based on search query
  function filterRecipes(searchQuery) {
    allRecipesSection.innerHTML = ""; // Clear the grid before displaying filtered recipes
    const filteredRecipes = allRecipes.filter((recipe) =>
      recipe.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (filteredRecipes.length === 0) {
      allRecipesSection.innerHTML = "<p class='no-recipes-message'>No recipes found.</p>";
    } else {
      filteredRecipes.forEach(displayRecipe);
    }
  }

  // Event listeners for search functionality
  searchIcon.addEventListener("click", () => {
    const searchQuery = searchInput.value.trim();
    filterRecipes(searchQuery);
  });

  searchInput.addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
      const searchQuery = searchInput.value.trim();
      filterRecipes(searchQuery);
    }
  });

  // Initial fetch of all recipes
  fetchRecipes();
}

// Call loadAllRecipes when the DOM is fully loaded
document.addEventListener("DOMContentLoaded", loadAllRecipes);
