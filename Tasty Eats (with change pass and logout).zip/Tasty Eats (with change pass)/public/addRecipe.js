// Import necessary Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Check if user is logged in before allowing them to add a recipe
let currentUser = null;

// Monitor authentication state
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
  } else {
    alert("You must be logged in to add a recipe.");
    window.location.href = "index.html"; // Redirect to login page if not logged in
  }
});

// Set up Cloudinary upload widget for recipe images
document.getElementById("uploadWidget").addEventListener("click", function () {
  cloudinary.openUploadWidget(
    {
      cloudName: "dgdzmrhc4",
      uploadPreset: "recipe-images-upload",
      folder: "recipe_images",
      sources: ["local", "url"],
    },
    (error, result) => {
      if (error) {
        alert("Error uploading image. Please try again.");
        console.error("Error uploading image:", error);
      } else if (result && result.event === "success") {
        // Display the uploaded image URL in the form
        document.getElementById("imageURL").value = result.info.secure_url;

        // Show a preview of the uploaded image
        const previewElement = document.getElementById("imagePreview");
        if (previewElement) {
          previewElement.src = result.info.secure_url;
          previewElement.style.display = "block";
        }
      }
    }
  );
});

// Popup controls
const popup = document.getElementById("popup");
const popupOkButton = document.getElementById("popup-ok");

function openPopup() {
  popup.classList.add("open-popup");
}

function closePopup() {
  popup.classList.remove("open-popup");
}

// Attach close event to popup OK button
popupOkButton.addEventListener("click", closePopup);

// Handle recipe form submission
const recipeForm = document.getElementById("recipeForm");
recipeForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const recipeTitle = document.getElementById("recipeTitle").value.trim();
  const instructions = document.getElementById("instructions").value.trim();
  const ingredients = document.getElementById("ingredients").value.trim().split(",");
  const imageUrl = document.getElementById("imageURL").value;

  // Validate form fields
  if (!recipeTitle || !instructions || !ingredients.length || !imageUrl) {
    alert("Please fill out all fields, including the image!");
    return;
  }

  try {
    if (!currentUser) {
      alert("You must be logged in to add a recipe.");
      return;
    }

    // Save recipe details to Firestore
    await addDoc(collection(db, "recipes"), {
      title: recipeTitle,
      instructions,
      ingredients,
      imageUrl,
      userId: currentUser.uid,
      timestamp: new Date(),
    });

    openPopup(); // Open success popup
    recipeForm.reset();

    // Reset image preview
    const previewElement = document.getElementById("imagePreview");
    if (previewElement) {
      previewElement.style.display = "none";
    }
  } catch (error) {
    console.error("Error adding recipe:", error);
    alert("Failed to add recipe. Please try again.");
  }
});

document.getElementById("uploadWidget").addEventListener("click", function () {
  // Trigger the Cloudinary widget (or your custom upload logic)
  cloudinary.openUploadWidget(
      { cloudName: "your_cloud_name", uploadPreset: "your_upload_preset" },
      (error, result) => {
          if (!error && result.event === "success") {
              const imageURL = result.info.secure_url;

              // Set the image preview and show it
              const imagePreview = document.getElementById("imagePreview");
              imagePreview.src = imageURL;
              imagePreview.style.display = "block";

              // Hide the upload button
              document.getElementById("uploadWidget").style.display = "none";
          }
      }
  );
});
