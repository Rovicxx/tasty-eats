import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import {
    getAuth,
    signInWithEmailAndPassword,
    GoogleAuthProvider,
    signInWithPopup
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const popup = document.getElementById("popup");
const okButton = document.getElementById("popup-ok");

// Open popup
function openPopup() {
    popup.classList.add("open-popup");
}

// Close popup
function closePopup() {
    popup.classList.remove("open-popup");
    window.location.href = "landing.html";
}

// Attach event listener to the OK button
okButton.addEventListener("click", closePopup);

// Handle email/password login
document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    try {
        await signInWithEmailAndPassword(auth, email, password);
        openPopup();
    } catch (error) {
        console.error("Error during login:", error);
        alert(`Login failed: ${error.message}`);
    }
});

// Google Sign-In
document.getElementById("googleSignIn").addEventListener("click", async () => {
    const provider = new GoogleAuthProvider();
    try {
        await signInWithPopup(auth, provider);
        alert("Signed in successfully with Google! Redirecting...");
        window.location.href = "landing.html";
    } catch (error) {
        console.error("Error with Google sign-in:", error);
        alert(`Failed to sign in with Google: ${error.message}`);
    }
});